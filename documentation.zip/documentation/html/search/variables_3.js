var searchData=
[
  ['ticket_0',['ticket',['../class_tour.html#a02c6bde87a2d3be6313e74974aafde95',1,'Tour']]],
  ['type_1',['type',['../class_burning_ticket.html#a3c0edb28ec9c02fc31170937d64c212d',1,'BurningTicket']]]
];
