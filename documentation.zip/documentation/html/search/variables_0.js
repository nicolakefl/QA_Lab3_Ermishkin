var searchData=
[
  ['item1_0',['item1',['../class_agency.html#a6ee97b72d3668f6c17cb4874e6ee2ce1',1,'Agency']]],
  ['item2_1',['item2',['../class_agency.html#a99d4d99d641e70ff5d6faf8605b39c3d',1,'Agency']]]
];
