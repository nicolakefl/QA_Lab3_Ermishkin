var searchData=
[
  ['total_0',['Total',['../class_tour.html#ae68a6c0278c9ca9e0d54d5ef8476ec23',1,'Tour::Total()'],['../class_burning_ticket.html#a2b3910d84224a2ec0b0bdbe7cd8196d7',1,'BurningTicket::Total(int t)']]],
  ['type_1',['Type',['../class_burning_ticket.html#acc0fa2654521b26481bec9f625888013',1,'BurningTicket']]]
];
